# Laberinto
Debe mostrar el laberinto con el personaje,las paredes y la salida 
El laberinto se dibuja con respecto a la matriz, donde los 1 son paredes, los 0 espacios vacios, la x es el personaje y la W la salida.
El personaje solo podra pasar por los espacios vacios.
Cuando el personaje llegue a la salida terminara el juego.

# Diagrama:

- diagrama de casos de uso:
![Casos de usos](out/diagramas/casos_de_uso/casos_de_uso.png)
- Diagrama de clases:
![Clases](out/diagramas/clases/clases.png)
- Diagrama de secuencia: